var Event = function(app) {
	this.app = app;
};

module.exports = Event;

Event.prototype.bind_session = function(session) {
};